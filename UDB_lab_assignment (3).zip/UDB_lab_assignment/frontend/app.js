const API = 'http://127.0.0.1:5000/api';

let currentPostId = null;
let currentLiked  = false;

// ── AUTH ─────────────────────────────────────────────────────
function getSession() {
  const s = localStorage.getItem('gram_session');
  return s ? JSON.parse(s) : null;
}

function setSession(id, username) {
  localStorage.setItem('gram_session', JSON.stringify({ id, username }));
}

function clearSession() {
  localStorage.removeItem('gram_session');
}

function initAuth() {
  const session = getSession();
  if (session) {
    showApp(session);
  } else {
    showLogin();
  }
}

function showLogin() {
  document.getElementById('login-screen').style.display  = 'flex';
  document.getElementById('sidebar').style.display       = 'none';
  document.getElementById('main-content').style.display  = 'none';
}

function showApp(session) {
  document.getElementById('login-screen').style.display  = 'none';
  document.getElementById('sidebar').style.display       = 'flex';
  document.getElementById('main-content').style.display  = 'block';
  document.getElementById('logged-in-as').textContent    = '@' + session.username;
  loadPosts();
}

async function login() {
  const username = document.getElementById('login-username').value.trim();
  const password = document.getElementById('login-password').value.trim();

  if (!username || !password) {
    showMsg('login-msg', 'Both fields are required.', true); return;
  }

  try {
    const res  = await fetch(`${API}/users/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    const data = await res.json();
    if (res.ok) {
      setSession(data.id, data.username);
      showApp(data);
    } else {
      showMsg('login-msg', data.error || 'Login failed.', true);
    }
  } catch {
    showMsg('login-msg', 'Server error. Is Flask running?', true);
  }
}

function logout() {
  clearSession();
  showLogin();
}

function switchToRegister() {
  document.getElementById('form-login').style.display    = 'none';
  document.getElementById('form-register').style.display = 'block';
  document.getElementById('login-sub').textContent       = 'Create your account';
  document.getElementById('login-msg').textContent       = '';
}

function switchToLogin() {
  document.getElementById('form-register').style.display = 'none';
  document.getElementById('form-login').style.display    = 'block';
  document.getElementById('login-sub').textContent       = 'Sign in to continue';
  document.getElementById('login-msg').textContent       = '';
}

async function registerAndLogin() {
  const username = document.getElementById('reg2-username').value.trim();
  const email    = document.getElementById('reg2-email').value.trim();
  const bio      = document.getElementById('reg2-bio').value.trim();
  const password = document.getElementById('reg2-password').value.trim();

  if (!username || !email || !password) {
    showMsg('login-msg', 'Username, email and password are required.', true); return;
  }

  try {
    // Step 1 — create user
    const res = await fetch(`${API}/users/`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, email, bio, password })
    });
    const data = await res.json();
    if (!res.ok) {
      showMsg('login-msg', data.error || 'Registration failed.', true); return;
    }

    // Step 2 — auto login
    const loginRes = await fetch(`${API}/users/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    const loginData = await loginRes.json();
    if (loginRes.ok) {
      setSession(loginData.id, loginData.username);
      showApp(loginData);
    } else {
      showMsg('login-msg', 'Registered! Now sign in.', false);
      switchToLogin();
    }
  } catch {
    showMsg('login-msg', 'Server error.', true);
  }
}
// ── NAVIGATION ───────────────────────────────────────────────
function showSection(name) {
  document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  document.getElementById(name).classList.add('active');
  document.querySelectorAll('.nav-btn').forEach(b => {
    if (b.textContent.toLowerCase().includes(name.slice(0,4))) b.classList.add('active');
  });
  if (name === 'feed')      loadPosts();
  if (name === 'users')     loadUsers();
  if (name === 'analytics') loadAnalytics();
}

// ── POSTS ────────────────────────────────────────────────────
async function loadPosts() {
  const container = document.getElementById('posts-container');
  container.innerHTML = '<div class="empty-state"><span class="emoji">⏳</span>Loading...</div>';
  try {
    const res   = await fetch(`${API}/posts/`);
    const posts = await res.json();
    if (!posts.length) {
      container.innerHTML = '<div class="empty-state"><span class="emoji">📭</span>No posts yet. Create one!</div>';
      return;
    }
    container.innerHTML = posts.map(p => `
      <div class="post-card" onclick="openPost('${p._id}')">
        ${p.image_url
          ? `<img src="${p.image_url}" alt="post image" onerror="this.style.display='none'">`
          : `<div class="post-card-no-img">📷</div>`}
        <div class="post-card-body">
          <div class="post-card-user">@${p.username || 'unknown'}</div>
          <div class="post-card-caption">${p.caption || 'No caption'}</div>
        </div>
        <div class="post-card-footer">
          <span>♡ likes</span>
          <span>💬 comments</span>
        </div>
      </div>
    `).join('');
  } catch {
    container.innerHTML = '<div class="empty-state"><span class="emoji">⚠️</span>Could not load posts. Is Flask running?</div>';
  }
}

function switchImageInput(type) {
  document.getElementById('btn-url').classList.toggle('active', type === 'url');
  document.getElementById('btn-file').classList.toggle('active', type === 'file');
  document.getElementById('post-image-url').style.display  = type === 'url'  ? 'block' : 'none';
  document.getElementById('post-image-file').style.display = type === 'file' ? 'block' : 'none';
}

async function uploadImage() {
  const fileInput = document.getElementById('post-image-file');
  if (!fileInput.files.length) return null;
  const formData = new FormData();
  formData.append('file', fileInput.files[0]);
  const res  = await fetch(`${API.replace('/api', '')}/api/upload`, {
    method: 'POST',
    body: formData
  });
  const data = await res.json();
  return res.ok ? data.url : null;
}

async function createPost() {
  const session  = getSession();
  const caption  = document.getElementById('post-caption').value.trim();
  const isFile   = document.getElementById('btn-file').classList.contains('active');

  if (!caption) { showMsg('post-msg', 'Caption is required.', true); return; }

  let imageUrl = '';
  if (isFile) {
    showMsg('post-msg', 'Uploading image...');
    imageUrl = await uploadImage() || '';
  } else {
    imageUrl = document.getElementById('post-image-url').value.trim();
  }

  try {
    const res = await fetch(`${API}/posts/`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ user_id: session.id, caption, image_url: imageUrl })
    });
    const data = await res.json();
    if (res.ok) {
      showMsg('post-msg', '✓ Post created!');
      document.getElementById('post-caption').value   = '';
      document.getElementById('post-image-url').value = '';
      document.getElementById('post-image-file').value = '';
    } else {
      showMsg('post-msg', data.error || 'Failed.', true);
    }
  } catch {
    showMsg('post-msg', 'Server error.', true);
  }
}
// ── MODAL ────────────────────────────────────────────────────
async function openPost(postId) {
  currentPostId = postId;
  currentLiked  = false;

  try {
    const [postRes, commentsRes, likeRes] = await Promise.all([
      fetch(`${API}/posts/${postId}`),
      fetch(`${API}/comments/post/${postId}`),
      fetch(`${API}/likes/count/${postId}`)
    ]);

    const post     = await postRes.json();
    const comments = await commentsRes.json();
    const likeData = await likeRes.json();

    document.getElementById('modal-username').textContent    = '@' + (post.username || 'unknown');
    document.getElementById('modal-date').textContent        = post.created_at
      ? new Date(post.created_at).toLocaleDateString() : '';
    document.getElementById('modal-caption').textContent     = post.caption || '';
    document.getElementById('modal-like-count').textContent  = likeData.count || 0;

    const imgWrap = document.getElementById('modal-image-wrap');
    imgWrap.innerHTML = post.image_url ? `<img src="${post.image_url}" alt="post">` : '';

    document.getElementById('modal-like-btn').classList.remove('liked');
    document.getElementById('comment-text').value = '';
    document.getElementById('comment-msg').textContent = '';

    renderComments(comments);
    document.getElementById('post-modal').classList.add('open');
  } catch {
    alert('Could not load post.');
  }
}

function renderComments(comments) {
  const container = document.getElementById('modal-comments');
  if (!comments.length) {
    container.innerHTML = '<div style="color:var(--muted);font-size:13px;">No comments yet.</div>';
    return;
  }
  container.innerHTML = comments.map(c => `
    <div class="comment-item">
      <strong>@${c.username || 'unknown'}</strong>
      ${c.text}
    </div>
  `).join('');
}

function closeModal(e) {
  if (e.target === document.getElementById('post-modal')) closeModalDirect();
}

function closeModalDirect() {
  document.getElementById('post-modal').classList.remove('open');
  currentPostId = null;
}

// ── LIKES ────────────────────────────────────────────────────
async function toggleLike() {
  const session   = getSession();
  const likeBtn   = document.getElementById('modal-like-btn');
  const countSpan = document.getElementById('modal-like-count');

  try {
    if (!currentLiked) {
      const res = await fetch(`${API}/likes/`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ post_id: currentPostId, user_id: session.id })
      });
      if (res.ok) {
        currentLiked = true;
        likeBtn.classList.add('liked');
        likeBtn.innerHTML = '♥ <span id="modal-like-count">' + (parseInt(countSpan.textContent) + 1) + '</span>';
      } else {
        showMsg('comment-msg', 'Already liked.', true);
      }
    } else {
      const res = await fetch(`${API}/likes/`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ post_id: currentPostId, user_id: session.id })
      });
      if (res.ok) {
        currentLiked = false;
        likeBtn.classList.remove('liked');
        likeBtn.innerHTML = '♡ <span id="modal-like-count">' + (parseInt(document.getElementById('modal-like-count').textContent) - 1) + '</span>';
      }
    }
  } catch {
    showMsg('comment-msg', 'Server error.', true);
  }
}

// ── COMMENTS ─────────────────────────────────────────────────
async function addComment() {
  const session = getSession();
  const text    = document.getElementById('comment-text').value.trim();

  if (!text) { showMsg('comment-msg', 'Comment cannot be empty.', true); return; }

  try {
    const res = await fetch(`${API}/comments/`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ post_id: currentPostId, user_id: session.id, text })
    });
    if (res.ok) {
      document.getElementById('comment-text').value = '';
      showMsg('comment-msg', '✓ Comment added!');
      const commentsRes = await fetch(`${API}/comments/post/${currentPostId}`);
      renderComments(await commentsRes.json());
    } else {
      showMsg('comment-msg', 'Failed to add comment.', true);
    }
  } catch {
    showMsg('comment-msg', 'Server error.', true);
  }
}

// ── USERS ────────────────────────────────────────────────────
async function loadUsers() {
  const container = document.getElementById('users-container');
  container.innerHTML = '<div class="empty-state"><span class="emoji">⏳</span>Loading...</div>';
  try {
    const res   = await fetch(`${API}/users/`);
    const users = await res.json();
    if (!users.length) {
      container.innerHTML = '<div class="empty-state"><span class="emoji">👤</span>No users yet.</div>';
      return;
    }
    container.innerHTML = users.map(u => `
      <div class="user-card">
        <div class="user-card-name">@${u.username}</div>
        <div class="user-card-email">${u.email}</div>
        <div class="user-card-bio">${u.bio || 'No bio'}</div>
      </div>
    `).join('');
  } catch {
    container.innerHTML = '<div class="empty-state"><span class="emoji">⚠️</span>Could not load users.</div>';
  }
}

async function createUser() {
  const username = document.getElementById('reg-username').value.trim();
  const email    = document.getElementById('reg-email').value.trim();
  const bio      = document.getElementById('reg-bio').value.trim();
  const password = document.getElementById('reg-password').value.trim();

  if (!username || !email || !password) {
    showMsg('user-msg', 'Username, email and password are required.', true); return;
  }

  try {
    const res = await fetch(`${API}/users/`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, email, bio, password })
    });
    const data = await res.json();
    if (res.ok) {
      showMsg('user-msg', `✓ User created!`);
      document.getElementById('reg-username').value = '';
      document.getElementById('reg-email').value    = '';
      document.getElementById('reg-bio').value      = '';
      document.getElementById('reg-password').value = '';
      loadUsers();
    } else {
      showMsg('user-msg', data.error || 'Failed.', true);
    }
  } catch {
    showMsg('user-msg', 'Server error.', true);
  }
}

// ── ANALYTICS ────────────────────────────────────────────────
async function loadAnalytics() {
  try {
    const [likedRes, activeRes, engRes] = await Promise.all([
      fetch(`${API}/analytics/most-liked`),
      fetch(`${API}/analytics/active-users`),
      fetch(`${API}/analytics/engagement`)
    ]);

    const liked  = await likedRes.json();
    const active = await activeRes.json();
    const eng    = await engRes.json();

    document.getElementById('most-liked-container').innerHTML = liked.length
      ? liked.map(r => `
          <div class="analytics-item">
            <span class="analytics-item-label">${r.caption || 'No caption'}</span>
            <span class="analytics-badge">♥ ${r.likeCount}</span>
          </div>`).join('')
      : '<div style="color:var(--muted);font-size:13px;">No data yet.</div>';

    document.getElementById('active-users-container').innerHTML = active.length
      ? active.map(r => `
          <div class="analytics-item">
            <span class="analytics-item-label">@${r.username}</span>
            <span class="analytics-badge orange">${r.postCount} posts</span>
          </div>`).join('')
      : '<div style="color:var(--muted);font-size:13px;">No data yet.</div>';

    document.getElementById('engagement-container').innerHTML = eng.length
      ? eng.map(r => `
          <div class="analytics-item">
            <span class="analytics-item-label">Post ${r.post_id.slice(-6)}</span>
            <div class="engagement-row">
              <span class="analytics-badge">♥ ${r.likes}</span>
              <span class="analytics-badge orange">💬 ${r.comments}</span>
            </div>
          </div>`).join('')
      : '<div style="color:var(--muted);font-size:13px;">No data yet.</div>';

  } catch {
    ['most-liked-container','active-users-container','engagement-container'].forEach(id => {
      document.getElementById(id).innerHTML = '<div style="color:var(--muted);font-size:13px;">Could not load data.</div>';
    });
  }
}

function showMsg(id, text, isError = false) {
  const el = document.getElementById(id);
  el.textContent = text;
  el.className = 'msg' + (isError ? ' error' : '');
  setTimeout(() => { el.textContent = ''; }, 4000);
}

initAuth();