from flask import Flask
from flask_cors import CORS

from routes.users    import users_bp
from routes.posts    import posts_bp
from routes.comments import comments_bp
from routes.likes    import likes_bp
from routes.analytics import analytics_bp

from flask import send_from_directory, request, jsonify
import os

UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app = Flask(__name__)
CORS(app)

app.register_blueprint(users_bp,    url_prefix="/api/users")
app.register_blueprint(posts_bp,    url_prefix="/api/posts")
app.register_blueprint(comments_bp, url_prefix="/api/comments")
app.register_blueprint(likes_bp,    url_prefix="/api/likes")
app.register_blueprint(analytics_bp,url_prefix="/api/analytics")

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)

@app.route('/api/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file'}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'Empty filename'}), 400
    ext = file.filename.rsplit('.', 1)[-1].lower()
    if ext not in {'jpg', 'jpeg', 'png', 'webp', 'gif'}:
        return jsonify({'error': 'Invalid file type'}), 400
    import uuid
    filename = f"{uuid.uuid4().hex}.{ext}"
    file.save(os.path.join(UPLOAD_FOLDER, filename))
    return jsonify({'url': f'http://127.0.0.1:5000/uploads/{filename}'}), 201

if __name__ == "__main__":
    app.run(debug=True, port=5000)