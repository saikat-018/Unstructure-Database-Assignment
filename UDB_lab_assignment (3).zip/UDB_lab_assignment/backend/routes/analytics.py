from flask import Blueprint, jsonify
from db import likes, posts, comments
from bson import ObjectId

analytics_bp = Blueprint("analytics", __name__)

@analytics_bp.route("/most-liked", methods=["GET"])
def most_liked():
    result = list(likes.aggregate([
        {"$group": {"_id": "$post_id", "likeCount": {"$sum": 1}}},
        {"$sort": {"likeCount": -1}},
        {"$limit": 5},
        {"$lookup": {
            "from": "posts",
            "localField": "_id",
            "foreignField": "_id",
            "as": "post"
        }},
        {"$unwind": "$post"},
        {"$project": {
            "likeCount": 1,
            "caption": "$post.caption"
        }}
    ]))
    for r in result:
        r["_id"] = str(r["_id"])
    return jsonify(result)

@analytics_bp.route("/active-users", methods=["GET"])
def active_users():
    result = list(posts.aggregate([
        {"$group": {"_id": "$user_id", "postCount": {"$sum": 1}}},
        {"$sort": {"postCount": -1}},
        {"$limit": 5},
        {"$lookup": {
            "from": "users",
            "localField": "_id",
            "foreignField": "_id",
            "as": "user"
        }},
        {"$unwind": "$user"},
        {"$project": {"postCount": 1, "username": "$user.username"}}
    ]))
    for r in result:
        r["_id"] = str(r["_id"])
    return jsonify(result)

@analytics_bp.route("/engagement", methods=["GET"])
def engagement():
    like_counts = {
        str(r["_id"]): r["count"]
        for r in likes.aggregate([
            {"$group": {"_id": "$post_id", "count": {"$sum": 1}}}
        ])
    }
    comment_counts = {
        str(r["_id"]): r["count"]
        for r in comments.aggregate([
            {"$group": {"_id": "$post_id", "count": {"$sum": 1}}}
        ])
    }
    all_ids = set(like_counts) | set(comment_counts)
    result = [
        {
            "post_id":  pid,
            "likes":    like_counts.get(pid, 0),
            "comments": comment_counts.get(pid, 0)
        }
        for pid in all_ids
    ]
    return jsonify(result)