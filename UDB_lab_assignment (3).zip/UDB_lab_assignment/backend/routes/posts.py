from flask import Blueprint, request, jsonify
from db import posts, users
from bson import ObjectId
from datetime import datetime

posts_bp = Blueprint("posts", __name__)

def fmt(doc):
    doc["_id"] = str(doc["_id"])
    doc["user_id"] = str(doc["user_id"])
    return doc

@posts_bp.route("/", methods=["POST"])
def create_post():
    data = request.json
    data["user_id"] = ObjectId(data["user_id"])
    data["created_at"] = datetime.utcnow()
    result = posts.insert_one(data)
    return jsonify({"id": str(result.inserted_id)}), 201

@posts_bp.route("/", methods=["GET"])
def get_posts():
    all_posts = []
    for p in posts.find().sort("created_at", -1):
        p = fmt(p)
        user = users.find_one({"_id": ObjectId(p["user_id"])})
        p["username"] = user["username"] if user else "Unknown"
        all_posts.append(p)
    return jsonify(all_posts)

@posts_bp.route("/<id>", methods=["GET"])
def get_post(id):
    post = posts.find_one({"_id": ObjectId(id)})
    return jsonify(fmt(post)) if post else ("Not found", 404)

@posts_bp.route("/<id>", methods=["PUT"])
def update_post(id):
    posts.update_one({"_id": ObjectId(id)}, {"$set": request.json})
    return jsonify({"message": "Updated"})

@posts_bp.route("/<id>", methods=["DELETE"])
def delete_post(id):
    posts.delete_one({"_id": ObjectId(id)})
    return jsonify({"message": "Deleted"})