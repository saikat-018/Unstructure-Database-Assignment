from flask import Blueprint, request, jsonify
from db import users
from bson import ObjectId
import bcrypt

users_bp = Blueprint("users", __name__)

def fmt(doc):
    doc["_id"] = str(doc["_id"])
    doc.pop("password", None)
    return doc

@users_bp.route("/", methods=["POST"])
def create_user():
    data = request.json
    if not data.get("password"):
        return jsonify({"error": "Password is required"}), 400
    try:
        data["password"] = bcrypt.hashpw(
            data["password"].encode("utf-8"),
            bcrypt.gensalt()
        ).decode("utf-8")
        result = users.insert_one(data)
        return jsonify({"id": str(result.inserted_id)}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@users_bp.route("/login", methods=["POST"])
def login():
    data = request.json
    username = data.get("username")
    password = data.get("password")

    if not username or not password:
        return jsonify({"error": "Username and password required"}), 400

    user = users.find_one({"username": username})
    if not user:
        return jsonify({"error": "User not found"}), 404

    if not bcrypt.checkpw(password.encode("utf-8"), user["password"].encode("utf-8")):
        return jsonify({"error": "Wrong password"}), 401

    return jsonify({"id": str(user["_id"]), "username": user["username"]}), 200

@users_bp.route("/", methods=["GET"])
def get_users():
    return jsonify([fmt(u) for u in users.find()])

@users_bp.route("/<id>", methods=["GET"])
def get_user(id):
    user = users.find_one({"_id": ObjectId(id)})
    if not user: return ("Not found", 404)
    return jsonify(fmt(user))

@users_bp.route("/<id>", methods=["PUT"])
def update_user(id):
    data = request.json
    if "password" in data:
        data["password"] = bcrypt.hashpw(
            data["password"].encode("utf-8"),
            bcrypt.gensalt()
        ).decode("utf-8")
    users.update_one({"_id": ObjectId(id)}, {"$set": data})
    return jsonify({"message": "Updated"})

@users_bp.route("/<id>", methods=["DELETE"])
def delete_user(id):
    users.delete_one({"_id": ObjectId(id)})
    return jsonify({"message": "Deleted"})